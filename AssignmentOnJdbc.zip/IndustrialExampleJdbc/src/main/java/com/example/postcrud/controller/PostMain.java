package com.example.postcrud.controller;

import java.sql.SQLException;
import java.util.Scanner;

import com.example.postcrud.model.Posts;
import com.example.postcrud.service.PostsService;
import com.example.postcrud.service.PostServiceImpl;

public class PostMain {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		PostsService service= new PostServiceImpl();
		System.out.println("Enter pid ");
		int pid = sc.nextInt();
		System.out.println("Enter title ");
		String title = sc.next();
		System.out.println("Enter author ");
		String author = sc.next();
		System.out.println("Enter description ");
		String description = sc.nextLine();
		String result = service.inserPost(new Posts(pid,author,title,description));
		
		System.out.println(result);
		
	}

}
