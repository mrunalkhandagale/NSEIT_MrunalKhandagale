package com.example.postcrud.controller;

import java.sql.SQLException;
import java.util.Scanner;

import com.example.postcrud.service.PostServiceImpl;
import com.example.postcrud.service.PostsService;

public class PostMain1 {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		PostsService service= new PostServiceImpl();
		System.out.println("Enter author ");
		String author = sc.next();
		
		String result = service.updatePost(author);
		System.out.println(result);

	}

}
