package com.example.postcrud.controller;

import java.sql.SQLException;
import java.util.Scanner;

import com.example.postcrud.service.PostServiceImpl;
import com.example.postcrud.service.PostsService;

public class PostMain2 {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		PostsService service= new PostServiceImpl();
		System.out.println("Enter pid ");
		int pid = sc.nextInt();
		
		String result = service.deletePost(pid);
		
		System.out.println(result);
	}

}
