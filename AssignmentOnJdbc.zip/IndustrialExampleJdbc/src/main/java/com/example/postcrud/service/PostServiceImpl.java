package com.example.postcrud.service;

import java.sql.SQLException;
import java.util.List;

import com.example.postcrud.dao.PostDao;
import com.example.postcrud.dao.PostDaoImpl;
import com.example.postcrud.model.Posts;

import com.example.postcrud.model.Posts;

public class PostServiceImpl implements PostsService{

	PostDao dao;
	
	public PostServiceImpl(){
		dao= new PostDaoImpl();
	}

	public List<Posts> getAllPosts() throws SQLException {
		// TODO Auto-generated method stub
		return dao.getAllPosts();
	}

	public String inserPost(Posts posts) throws SQLException {
		// TODO Auto-generated method stub
		return dao.inserPost(posts);
	}

	public String deletePost(int pid) throws SQLException {
		// TODO Auto-generated method stub
		return dao.deletePost(pid);
	}

	public String updatePost(String author) throws SQLException {
		// TODO Auto-generated method stub
		return dao.updatePost(author);
	}

	

}
